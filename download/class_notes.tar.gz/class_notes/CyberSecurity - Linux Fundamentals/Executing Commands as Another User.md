Cybersecurity Linux Lesson 1.2.3
___
### Accessing Files and Executing Commands as Other Users
- In some cases, files may need to be accessed by other users within a system or commands may need to be executed through the root user when performing administrative tasks
- The `su –` command, where the – is the username, allows a user to login as another in order to access certain files or permissions
- Commands can be executed by running `su <username> -c <command>`
- Typing `exit` will return the user to the original account

### Running Commands with Sudo
- Allowing multiple users to have admin credentials poses a security threat to the system
- The `sudo` command allows a user to run a command with admin privileges without having to login as the root user

### Sudoers File
- Not just any user can use the sudo command
- As a security feature of Linux systems, the user must be listed in the sudoers file, located at `/etc/sudoers`
- If not listed, the user will not be allowed to use sudo and the incident is logged

### Editing the Sudoers File
- Editing the sudoers file requires root access and some additional security precautions
- Issues can arise if the sudoers file is open or edited by multiple people
- Typically, the sudoers file is open using the visudo editor which does a check to see if the file is open by another user
- If it is open already then, the file is opened as read-only

### PolicyKit
- Also referred to as PolKit - Allows fine tuning of administrative privileges such as mounting drives, changing systems, installing software, and more
- When a task is performed, PolicyKit will check it against the rules in place to determine if the user has sufficient rights
- `pkexec` is common command allowing a user to execute commands as the root user