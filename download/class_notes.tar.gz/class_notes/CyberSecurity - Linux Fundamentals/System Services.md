Cybersecurity Linux Lesson 1.2.3
___
System Services
- Essential background processes that are often initiated during the boot process
- Manage hardware - Handle user authentication
- Facilitate communication between programs
- Crucial in maintaining stability, security and efficiency

### System Services - systemctl
The systemctl command is used to manage services running on the system

| Commonly Used systemctl Commands |                                                         |
| -------------------------------- | ------------------------------------------------------- |
| systemctl stop `<service-name>`    | Stops the service specified                             |
| systemctl start `<service-name>`   | Starts the service specified                            |
| systemctl restart `<service-name>` | Restarts the service specified                          |
| systemctl status `<service-name>`  | Provide the status of the service specified             |
| systemctl enable `<service-name>`  | Enables the service specified to start at boot          |
| systemctl disable `<service-name>` | Disables the service specified to not start at boot     |
| systemctl mask `<service-name>`    | Prevents the service specified from running or starting |

### Scheduling Services
- Cron is a time-based job scheduler in Unix-like OSs
	- Allows users to schedule tasks to run periodically
	- Jobs are defined using the cron syntax
- `crontab` is a command-line utility that allows users to create, edit, and manage their cron jobs
	- Each user may have their own crontab file
- The `at` command is another scheduler in Unix-like systems
	- Used for one-time job scheduling
	- The at daemon executes it at a specified time