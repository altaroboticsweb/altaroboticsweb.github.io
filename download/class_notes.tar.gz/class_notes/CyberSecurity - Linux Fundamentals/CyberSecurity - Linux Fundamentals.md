# Chronological order:
## [[Linux Directories|1.1.1 Linux Directories]]
## [[File and directory managment|1.2.5 File and directory management]]
## [[Shell script elements|3.1.1 & 3.1.2 Shell script elements]]
### [[File editing|1.2.1 File editing]]
### [[Script Utils and Variables|3.1.3 Script Utilities and Variables]]
### [[Metadata|1.2.3 Metadata]]
### [[Account creation and deletion|2.2.1 Account creation and deletion]]
### [[Account configuration and management|2.2.2 Account configuration and managment]]
### [[Executing Commands as Another User|2.4.2 Executing Commands as Another User]]
### [[System Services|1.4.1 System Services]]

