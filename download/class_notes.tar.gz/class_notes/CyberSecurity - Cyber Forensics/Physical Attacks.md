Cybersecurity Forensics Lesson 2.4.7
___
### Physical Attacks
- Exploiting physical components or characteristics of an organization or system to compromise security protocols

### Common Physical Attacks
- Unauthorized Access
	- Gaining physical access to a system or facility without permission
- Hardware Tampering
	- Physically manipulating computer hardware to compromise its integrity or functionality
- Eavesdropping
	- Listening in on or intercepting communication by physically tapping into network cables or devices.
- Dumpster Diving
	- Searching through discarded materials, such as paper documents or electronic devices, to find sensitive information

### Common Physical Attacks
- Social Engineering Attacks
	- Manipulating individuals into divulging confidential information or performing actions that compromise security
- Electromagnetic Attacks
	- Exploiting electromagnetic signals to compromise or interfere with electronic systems
- Power Attacks
	- Exploiting vulnerabilities in the power supply to disrupt or compromise systems

### Brute Force Attacks
- A systematic attack that tests every possible combination of characters until whatever is being cracked, usually a password, falls
- Can be time consuming, but specialized hardware/ software and having a physical connection to the system can speed up the process
- Having a defined number of attempts before a lockout can assist in preventing a brute force attack JtR is used as a password cracker in the CYBER.ORG Range

### Radio Frequency Identification (RFID) Cloning
- Copying the data stored on an RFID card and transferring it to another device via RFID readers and writers
- Requires being within proximity of the target
- Cloned devices or cards can then be used to gain access
- RFID paired with other authentication measures or using smartphones rather than just cards can help to mitigate this issue

### Environmental
- Tampering with hardware, temperature and humidity exploitation, and physical security weaknesses
- Manipulation of hardware components, such as inserting malicious devices or modifying devices
- Manipulating temperature and humidity can cause several issues for sensitive equipment – hence the reason most server rooms have independent climate controls and backups