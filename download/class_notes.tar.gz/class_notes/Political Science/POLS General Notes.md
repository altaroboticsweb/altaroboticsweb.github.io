___
#### Unitarian governments:
Had a single national government that had total power over the the smaller sub-governments, Great Britian's gov system

#### Confederacy:
A complete flip to the unitarian government that the colonists had before, the problem was that the states were the more powerful side and caused the national government to haev very little power, the event that caused the idea to change this was Shay's Rebellion, showing that a national militia would be needed in case of the event of a single state being taken over

#### Federal Government:
A mix of state and national governments that we adopted that gave us the gov we have today, but we have a written constitution

## Federalism cases:
#### MCCULLOCH V MARYLAND:
Hamilton created a national government in the state of Maryland, it started being taxed by the state but the director would not pay these taxes, the state threatens to shut down the national bank and it sparked the court case
Does the national government have restrictions against having a national bank? No, using the necessary and proper clause it was determined to be a implied power of the national government
Does the state of Maryland have the right to tax the national bank? No, it was deemed as a federal government that has power over the state government, by using the supremacy clause they stated that the power of the state to tax the bank would be unjust and would destroy the national bank
The thought was that a national government would be very useful as a way to distribute money and to store national government money from things like tariffs and federal taxes

#### GIBBONS V OGDEN:
Steam boats that are able to go up and down rivers are used as a very useful trading technique, so two people decided to make a monopoly across the different rivers around the nation where they would lease out the boats for people to use. Hamilton and Madison were at the Annapolis convention that centered around the idea of waterway travel that sparked the constitutional convention. The issue was that the state of New York was the only state that would allow a monopoly, but since it was a interstate commerce deal, it had to go to court. So the idea of different types of trades were identified, interstate, intrastate, and international. Since the states under the confederacy would each have their own tariffs and taxes, it made trading with the U.S. a struggle for foreign merchants. **ONLY THE FEDERAL GOVERNMENT CAN CONTROL INTERSTATE COMMERCE.**

### Necessary and Proper Clause:
Can be used by the national government **AS LONG AS THE 10'TH AMENDMENT IS NOT AFFECTED**. One example is that when the federal government made a edict about the school system having vending machines in cafeterias, in UT the schools would make walls to obscure it so that it could not be seen from the eating area. In one case the federal government was able to fine a school $25000 for every day that a vending machine was out. This is because of the certain standards that school food has that the vending machine food is not regulated against, some other things that are regulated are the exit signs that all schools have to direct to the nearest exit, along with push bars to doors that go outside to prevent people getting stuck in cases where people need to get out fast.





# Essence of Government:
MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY MONEY 