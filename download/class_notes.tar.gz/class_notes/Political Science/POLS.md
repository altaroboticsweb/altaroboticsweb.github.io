### [[POLS General Notes|General Notes]]
### [[POLS Current Events Essay|Current Events Essay]]
